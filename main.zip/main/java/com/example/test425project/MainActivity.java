package com.example.test425project;

import androidx.annotation.CallSuper;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.connection.AdvertisingOptions;
import com.google.android.gms.nearby.connection.ConnectionInfo;
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback;
import com.google.android.gms.nearby.connection.ConnectionResolution;
import com.google.android.gms.nearby.connection.ConnectionsClient;
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo;
import com.google.android.gms.nearby.connection.DiscoveryOptions;
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback;
import com.google.android.gms.nearby.connection.Payload;
import com.google.android.gms.nearby.connection.PayloadCallback;
import com.google.android.gms.nearby.connection.PayloadTransferUpdate;
import com.google.android.gms.nearby.connection.Strategy;

import static java.nio.charset.StandardCharsets.UTF_8;

//https://github.com/googlearchive/android-nearby/tree/master/connections

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "PicItUp";

    private static final String[] REQUIRED_PERMISSIONS =
            new String[] {
                    Manifest.permission.BLUETOOTH,
                    Manifest.permission.BLUETOOTH_ADMIN,
                    Manifest.permission.ACCESS_WIFI_STATE,
                    Manifest.permission.CHANGE_WIFI_STATE,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
            };

    private static final int REQUEST_CODE_REQUIRED_PERMISSIONS = 1;

    private static final Strategy STRATEGY = Strategy.P2P_STAR;

    // Our handle to Nearby Connections
    private ConnectionsClient connectionsClient;

    // Our randomly generated name
    private String userName;
    private Payload.File[] userImages;
    private int[] userVotes;
    private int[] userRounds;
    private String[] userEndpointIDs;
    private String[] allUserNames;
    private int playerCounter=0;
    private int totalVotes=0;
    private int roundCount=1;

    private EditText playerName;
    private Button host;
    private Button join;
    private ImageView picture;
    private Button draw;
    private Button filter;
    private Button stickers;
    private Button clear;
    private Button submit;
    private TextView lobbyName;
    private ImageView hostPicture;
    private TextView hostName;
    private TextView player2;
    private TextView player3;
    private TextView player4;
    private Button start;
    private ImageView playerImage1;
    private ImageView playerImage2;
    private ImageView playerImage3;
    private ImageView playerImage4;
    private Button voteP1;
    private Button voteP2;
    private Button voteP3;
    private Button voteP4;

    // Callbacks for receiving payloads
    private final PayloadCallback payloadCallback =
            new PayloadCallback() {
                @Override
                public void onPayloadReceived(String endpointId, Payload payload) {
                    if(endpointId.equals(userEndpointIDs[1]))
                    {
                        userImages[1]=payload.asFile();
                    }
                    else if(endpointId.equals(userEndpointIDs[2]))
                    {
                        userImages[2]=payload.asFile();
                    }
                    else if(endpointId.equals(userEndpointIDs[3]))
                    {
                        userImages[3]=payload.asFile();
                    }

                }

                @Override
                public void onPayloadTransferUpdate(String endpointId, PayloadTransferUpdate update) {
                    if (update.getStatus() == PayloadTransferUpdate.Status.SUCCESS && userImages.length == allUserNames.length) {
                        startVoting();
                    }
                }
            };

    // Callbacks for finding other devices
    private final EndpointDiscoveryCallback endpointDiscoveryCallback =
            new EndpointDiscoveryCallback() {
                @Override
                public void onEndpointFound(String endpointId, DiscoveredEndpointInfo info) {
                    Log.i(TAG, "onEndpointFound: endpoint found, connecting");
                    connectionsClient.requestConnection(userName, endpointId, connectionLifecycleCallback);
                }

                @Override
                public void onEndpointLost(String endpointId) {}
            };

    // Callbacks for connections to other devices
    private final ConnectionLifecycleCallback connectionLifecycleCallback =
            new ConnectionLifecycleCallback() {
                @Override
                public void onConnectionInitiated(String endpointId, ConnectionInfo connectionInfo) {
                    Log.i(TAG, "onConnectionInitiated: accepting connection");
                    connectionsClient.acceptConnection(endpointId, payloadCallback);
                    if(playerCounter==1)
                    {
                        allUserNames[1]=connectionInfo.getEndpointName();
                        playerCounter++;
                    }
                    else if(playerCounter==2)
                    {
                        allUserNames[2]=connectionInfo.getEndpointName();
                        playerCounter++;
                    }
                    else if(playerCounter==3)
                    {
                        allUserNames[3]=connectionInfo.getEndpointName();
                        playerCounter++;
                    }
                }

                @Override
                public void onConnectionResult(String endpointId, ConnectionResolution result) {
                    if (result.getStatus().isSuccess()) {
                        Log.i(TAG, "onConnectionResult: connection successful");
                        setContentView(R.layout.lobby);
                        if(allUserNames[0]!=null)
                        {
                            hostName.setText(allUserNames[0]);
                        }
                        if(allUserNames[1]!=null)
                        {
                            player2.setText(allUserNames[1]);
                        }
                        if(allUserNames[2]!=null)
                        {
                            player3.setText(allUserNames[2]);
                        }
                        if(allUserNames[3]!=null)
                        {
                            player4.setText(allUserNames[3]);
                        }

                    } else {
                        Log.i(TAG, "onConnectionResult: connection failed");
                    }
                }

                @Override
                public void onDisconnected(String endpointId) {
                    Log.i(TAG, "onDisconnected: disconnected from the opponent");
                    resetGame();
                }
            };

    @Override
    protected void onCreate(@Nullable Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);

        playerName=findViewById(R.id.playerName);
        host=findViewById(R.id.host);
        join=findViewById(R.id.join);
        picture=findViewById(R.id.hostPicture);
        draw=findViewById(R.id.draw);
        filter=findViewById(R.id.filter);
        stickers=findViewById(R.id.stickers);
        clear=findViewById(R.id.clear);
        submit=findViewById(R.id.submit);
        lobbyName=findViewById(R.id.lobbyName);
        hostPicture=findViewById(R.id.hostPicture);
        hostName=findViewById(R.id.hostName);
        player2=findViewById(R.id.player2);
        player3=findViewById(R.id.player3);
        player4=findViewById(R.id.player4);
        start=findViewById(R.id.start);
        playerImage1=findViewById(R.id.playerImage1);
        playerImage2=findViewById(R.id.playerImage2);
        playerImage3=findViewById(R.id.playerImage3);
        playerImage4=findViewById(R.id.playerImage4);
        voteP1=findViewById(R.id.voteP1);
        voteP2=findViewById(R.id.voteP2);
        voteP3=findViewById(R.id.voteP3);
        voteP4=findViewById(R.id.voteP4);
        userEndpointIDs=new String[4];
        allUserNames=new String[4];
        userImages=new Payload.File[4];
        userVotes=new int[4];
        userRounds=new int[4];

        connectionsClient = Nearby.getConnectionsClient(this);

        resetGame();
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (!hasPermissions(this, REQUIRED_PERMISSIONS)) {
            requestPermissions(REQUIRED_PERMISSIONS, REQUEST_CODE_REQUIRED_PERMISSIONS);
        }
    }

    @Override
    protected void onStop() {
        connectionsClient.stopAllEndpoints();
        resetGame();

        super.onStop();
    }

    /** Returns true if the app was granted all the permissions. Otherwise, returns false. */
    private static boolean hasPermissions(Context context, String... permissions) {
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(context, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    /** Handles user acceptance (or denial) of our permission request. */
    @CallSuper
    @Override
    public void onRequestPermissionsResult(
            int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode != REQUEST_CODE_REQUIRED_PERMISSIONS) {
            return;
        }

        for (int grantResult : grantResults) {
            if (grantResult == PackageManager.PERMISSION_DENIED) {
                Toast.makeText(this, "Game cannot proceed without the required permissions", Toast.LENGTH_LONG).show();
                finish();
                return;
            }
        }
        recreate();
    }

    public void joinClick(View view) {
        userName=playerName.getText().toString();
        allUserNames[0]=userName;
        startAdvertising();
        startDiscovery();
    }

    public void hostClick(View view) {
        userName=playerName.getText().toString();
        allUserNames[0]=userName;
        startAdvertising();
        startDiscovery();
    }

    public void startGameClick(View view) {
        connectionsClient.stopDiscovery();
        connectionsClient.stopAdvertising();
        setContentView(R.layout.game);
    }

    public void startVoting() {
        setContentView(R.layout.photos);
        totalVotes=userVotes[0]+userVotes[1]+userVotes[2]+userVotes[3];

        //wait for all votes
        while(totalVotes!=allUserNames.length)
        {
            totalVotes=userVotes[0]+userVotes[1]+userVotes[2]+userVotes[3];
        }

        //find highest votes
        int highestIndex=0;
        int tiedIndex=0;
        for(int i=1;i<4;i++) {
            if(userVotes[i]>userVotes[highestIndex])
            {
                highestIndex=i;
            }
            else if(userVotes[i]==userVotes[highestIndex]) {
                tiedIndex=i;
            }
        }

        //assign round score
        if(tiedIndex==0) {
            userRounds[highestIndex]=userRounds[highestIndex]+1;
        }
        else {
            userRounds[highestIndex]=userRounds[highestIndex]+1;
            userRounds[tiedIndex]=userRounds[tiedIndex]+1;
        }

        //reset votes
        for(int j=0;j<4;j++) {
            userVotes[j]=0;
        }

        /** UPDATE SCOREBOARD and add wait*/

        if(roundCount==3) {
            endGame();
        }
        roundCount++;
        setContentView(R.layout.game);
    }

    public void p1Vote(View view) {
        userVotes[0]=userVotes[0]+1;
    }

    public void p2Vote(View view) {
        userVotes[1]=userVotes[1]+1;
    }

    public void p3Vote(View view) {
        userVotes[2]=userVotes[2]+1;
    }

    public void p4Vote(View view) {
        userVotes[3]=userVotes[3]+1;
    }

    /** Disconnects from the opponent and reset the UI. */
    public void disconnect(View view) {
        connectionsClient.stopAllEndpoints();
        resetGame();
    }


    /** Starts looking for other players using Nearby Connections. */
    private void startDiscovery() {
        connectionsClient.startDiscovery(
                getPackageName(), endpointDiscoveryCallback,
                new DiscoveryOptions.Builder().setStrategy(STRATEGY).build());
    }

    /** Broadcasts our presence using Nearby Connections so other players can find us. */
    private void startAdvertising() {
        connectionsClient.startAdvertising(
                userName, getPackageName(), connectionLifecycleCallback,
                new AdvertisingOptions.Builder().setStrategy(STRATEGY).build());
    }



    /** Sends the user's selection of rock, paper, or scissors to the opponent. */
    private void sendGameChoice(GameChoice choice) {
        myChoice = choice;
        connectionsClient.sendPayload(
                opponentEndpointId, Payload.fromBytes(choice.name().getBytes(UTF_8)));

        setStatusText(getString(R.string.game_choice, choice.name()));
        // No changing your mind!
        setGameChoicesEnabled(false);
    }







}